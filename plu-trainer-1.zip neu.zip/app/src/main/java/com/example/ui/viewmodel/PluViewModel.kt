package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.LearningStats
import com.example.data.model.PluProduct
import com.example.data.model.RecognizedPluItem
import com.example.data.repository.PluRepository
import com.example.data.service.PluRecognitionService
import com.example.data.service.RecognitionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PracticeUiState(
    val currentProduct: PluProduct? = null,
    val enteredPlu: String = "",
    val isChecked: Boolean = false,
    val isCorrect: Boolean? = null,
    val streak: Int = 0,
    val sessionCorrect: Int = 0,
    val sessionTotal: Int = 0,
    val noProductsAvailable: Boolean = false
)

data class RecognitionUiState(
    val selectedUris: List<Uri> = emptyList(),
    val isAnalyzing: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,
    val recognizedItems: List<RecognizedPluItem> = emptyList(),
    val saveSuccess: Boolean = false
)

class PluViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PluRepository
    private val recognitionService: PluRecognitionService

    init {
        val database = AppDatabase.getDatabase(application)
        repository = PluRepository(database.pluProductDao())
        recognitionService = PluRecognitionService(application)
    }

    val stats: StateFlow<LearningStats> = repository.stats
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = LearningStats()
        )

    val allProducts: StateFlow<List<PluProduct>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow("Alle")
    val selectedCategoryFilter = _selectedCategoryFilter.asStateFlow()

    val filteredProducts: StateFlow<List<PluProduct>> = combine(
        allProducts,
        _searchQuery,
        _selectedCategoryFilter
    ) { products, query, filter ->
        products.filter { product ->
            val matchesQuery = query.isBlank() ||
                    product.name.contains(query, ignoreCase = true) ||
                    product.plu.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                "Alle" -> true
                "Gelernt" -> product.learningStatus.label == "Gelernt"
                "Zu üben" -> product.learningStatus.label != "Gelernt"
                else -> product.category.contains(filter, ignoreCase = true)
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Image & OCR Recognition State
    private val _recognitionState = MutableStateFlow(RecognitionUiState())
    val recognitionState = _recognitionState.asStateFlow()

    // Practice State
    private val _practiceState = MutableStateFlow(PracticeUiState())
    val practiceState = _practiceState.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(filter: String) {
        _selectedCategoryFilter.value = filter
    }

    // ==================== IMAGE / SCAN FLOW ====================

    fun addSelectedImageUri(uri: Uri) {
        _recognitionState.update { current ->
            current.copy(
                selectedUris = current.selectedUris + uri,
                errorMessage = null
            )
        }
    }

    fun addSelectedImageUris(uris: List<Uri>) {
        _recognitionState.update { current ->
            current.copy(
                selectedUris = current.selectedUris + uris,
                errorMessage = null
            )
        }
    }

    fun removeSelectedImageUri(uri: Uri) {
        _recognitionState.update { current ->
            current.copy(selectedUris = current.selectedUris.filter { it != uri })
        }
    }

    fun clearSelectedImages() {
        _recognitionState.update { it.copy(selectedUris = emptyList(), errorMessage = null) }
    }

    fun startImageAnalysis(onSuccessNav: () -> Unit) {
        val uris = _recognitionState.value.selectedUris
        if (uris.isEmpty()) {
            _recognitionState.update {
                it.copy(errorMessage = "Bitte wähle zuerst mindestens ein Foto aus.")
            }
            return
        }

        viewModelScope.launch {
            _recognitionState.update {
                it.copy(
                    isAnalyzing = true,
                    statusMessage = "KI analysiert Bildzeilen und Tabellenstruktur...",
                    errorMessage = null
                )
            }

            val result = recognitionService.analyzeImageUris(uris)
            when (result) {
                is RecognitionResult.Success -> {
                    // Check against existing database items to flag duplicates
                    val existingProducts = allProducts.value
                    val processedItems = result.items.map { item ->
                        val match = existingProducts.find { it.plu == item.plu.trim() }
                        if (match != null) {
                            item.copy(isDuplicateOfExisting = true, existingId = match.id)
                        } else {
                            item
                        }
                    }

                    _recognitionState.update {
                        it.copy(
                            isAnalyzing = false,
                            statusMessage = null,
                            errorMessage = null,
                            recognizedItems = processedItems
                        )
                    }
                    onSuccessNav()
                }
                is RecognitionResult.Error -> {
                    _recognitionState.update {
                        it.copy(
                            isAnalyzing = false,
                            statusMessage = null,
                            errorMessage = result.userMessage
                        )
                    }
                }
            }
        }
    }

    fun updateRecognizedItem(tempId: String, newName: String, newPlu: String, newCategory: String = "Obst & Gemüse") {
        _recognitionState.update { state ->
            val existingProducts = allProducts.value
            val match = existingProducts.find { it.plu == newPlu.trim() }

            val updated = state.recognizedItems.map { item ->
                if (item.tempId == tempId) {
                    item.copy(
                        name = newName,
                        plu = newPlu,
                        category = newCategory,
                        isDuplicateOfExisting = match != null,
                        existingId = match?.id
                    )
                } else {
                    item
                }
            }
            state.copy(recognizedItems = updated)
        }
    }

    fun updateRecognizedItemDuplicateAction(tempId: String, action: com.example.data.model.DuplicateAction) {
        _recognitionState.update { state ->
            val updated = state.recognizedItems.map { item ->
                if (item.tempId == tempId) {
                    item.copy(duplicateAction = action)
                } else {
                    item
                }
            }
            state.copy(recognizedItems = updated)
        }
    }

    fun removeRecognizedItem(tempId: String) {
        _recognitionState.update { state ->
            state.copy(recognizedItems = state.recognizedItems.filter { it.tempId != tempId })
        }
    }

    fun addManualRecognizedItem() {
        val newItem = RecognizedPluItem(
            name = "",
            plu = "",
            category = "Obst & Gemüse",
            emoji = "🏷️",
            confidence = 1.0
        )
        _recognitionState.update { state ->
            state.copy(recognizedItems = listOf(newItem) + state.recognizedItems)
        }
    }

    fun saveAllRecognizedItems(onComplete: () -> Unit) {
        viewModelScope.launch {
            val validItems = _recognitionState.value.recognizedItems
                .filter { it.name.isNotBlank() && it.plu.isNotBlank() }

            if (validItems.isEmpty()) return@launch

            // Filter out items that the user chose to SKIP
            val itemsToProcess = validItems.filter { item ->
                !(item.isDuplicateOfExisting && item.duplicateAction == com.example.data.model.DuplicateAction.SKIP)
            }

            if (itemsToProcess.isEmpty()) {
                onComplete()
                return@launch
            }

            val products = itemsToProcess.map { item ->
                val targetId = if (item.isDuplicateOfExisting && item.duplicateAction == com.example.data.model.DuplicateAction.UPDATE) {
                    item.existingId ?: 0L
                } else {
                    0L // Save as new product
                }

                PluProduct(
                    id = targetId,
                    plu = item.plu.trim(),
                    name = item.name.trim(),
                    category = item.category.trim(),
                    emoji = item.emoji.ifBlank { "🏷️" }
                )
            }

            repository.insertProducts(products)
            _recognitionState.update {
                it.copy(
                    recognizedItems = emptyList(),
                    selectedUris = emptyList(),
                    saveSuccess = true
                )
            }
            onComplete()
        }
    }

    // ==================== PRACTICE MODE FLOW ====================

    fun startPracticeSession() {
        val products = allProducts.value
        if (products.isEmpty()) {
            _practiceState.value = PracticeUiState(noProductsAvailable = true)
            return
        }
        val firstProduct = repository.selectNextPracticeProduct(products)
        _practiceState.value = PracticeUiState(
            currentProduct = firstProduct,
            enteredPlu = "",
            isChecked = false,
            isCorrect = null,
            streak = 0,
            sessionCorrect = 0,
            sessionTotal = 0,
            noProductsAvailable = false
        )
    }

    fun onPluInputChanged(input: String) {
        if (!_practiceState.value.isChecked) {
            _practiceState.update { it.copy(enteredPlu = input.filter { char -> char.isDigit() }) }
        }
    }

    fun checkPracticeAnswer() {
        val state = _practiceState.value
        val product = state.currentProduct ?: return
        if (state.enteredPlu.isBlank()) return

        val isCorrect = state.enteredPlu.trim() == product.plu.trim()
        val newStreak = if (isCorrect) state.streak + 1 else 0
        val newSessionCorrect = if (isCorrect) state.sessionCorrect + 1 else state.sessionCorrect
        val newSessionTotal = state.sessionTotal + 1

        _practiceState.update {
            it.copy(
                isChecked = true,
                isCorrect = isCorrect,
                streak = newStreak,
                sessionCorrect = newSessionCorrect,
                sessionTotal = newSessionTotal
            )
        }

        viewModelScope.launch {
            repository.recordPracticeResult(product.id, isCorrect)
        }
    }

    fun nextPracticeProduct() {
        val products = allProducts.value
        if (products.isEmpty()) {
            _practiceState.update { it.copy(noProductsAvailable = true) }
            return
        }

        val currentId = _practiceState.value.currentProduct?.id
        val next = repository.selectNextPracticeProduct(products, currentId)

        _practiceState.update {
            it.copy(
                currentProduct = next,
                enteredPlu = "",
                isChecked = false,
                isCorrect = null
            )
        }
    }

    // ==================== PRODUCT MANAGEMENT ====================

    fun saveProduct(product: PluProduct) {
        viewModelScope.launch {
            if (product.id == 0L) {
                repository.insertProduct(product)
            } else {
                repository.updateProduct(product)
            }
        }
    }

    fun deleteProduct(product: PluProduct) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun seedSampleData() {
        viewModelScope.launch {
            repository.seedSampleProducts()
        }
    }

    fun resetStats() {
        viewModelScope.launch {
            repository.resetStats()
            if (_practiceState.value.currentProduct != null) {
                startPracticeSession()
            }
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            repository.deleteAll()
            _practiceState.value = PracticeUiState(noProductsAvailable = true)
        }
    }
}
