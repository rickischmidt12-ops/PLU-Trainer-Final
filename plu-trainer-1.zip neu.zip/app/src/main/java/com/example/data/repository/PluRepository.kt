package com.example.data.repository

import com.example.data.dao.PluProductDao
import com.example.data.model.LearningStats
import com.example.data.model.LearningStatus
import com.example.data.model.PluProduct
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlin.random.Random

class PluRepository(private val dao: PluProductDao) {

    val allProducts: Flow<List<PluProduct>> = dao.getAllProducts()

    val stats: Flow<LearningStats> = dao.getAllProducts().map { list ->
        if (list.isEmpty()) {
            LearningStats()
        } else {
            val totalProducts = list.size
            val totalCorrect = list.sumOf { it.correctCount }
            val totalWrong = list.sumOf { it.wrongCount }
            val totalAttempts = totalCorrect + totalWrong
            val overallAccuracy = if (totalAttempts > 0) {
                ((totalCorrect.toDouble() / totalAttempts) * 100).toInt()
            } else {
                0
            }
            val masteredCount = list.count { it.learningStatus == LearningStatus.MASTERED }
            val toLearnCount = totalProducts - masteredCount
            val totalPracticed = list.count { it.totalAttempts > 0 }

            LearningStats(
                totalProducts = totalProducts,
                overallAccuracy = overallAccuracy,
                toLearnCount = toLearnCount,
                masteredCount = masteredCount,
                totalPracticed = totalPracticed
            )
        }
    }

    fun searchProducts(query: String): Flow<List<PluProduct>> = dao.searchProducts(query)

    suspend fun getProductById(id: Long): PluProduct? = dao.getProductById(id)

    suspend fun getProductByPlu(plu: String): PluProduct? = dao.getProductByPlu(plu.trim())

    suspend fun insertProduct(product: PluProduct): Long = dao.insert(product.copy(plu = product.plu.trim()))

    suspend fun insertProducts(products: List<PluProduct>): List<Long> {
        val sanitized = products.map { it.copy(plu = it.plu.trim()) }
        return dao.insertAll(sanitized)
    }

    suspend fun updateProduct(product: PluProduct) = dao.update(product.copy(plu = product.plu.trim()))

    suspend fun deleteProduct(product: PluProduct) = dao.delete(product)

    suspend fun deleteProductById(id: Long) = dao.deleteById(id)

    suspend fun deleteAll() = dao.deleteAll()

    suspend fun resetStats() = dao.resetStats()

    suspend fun recordPracticeResult(productId: Long, isCorrect: Boolean) {
        val product = dao.getProductById(productId) ?: return
        val updated = if (isCorrect) {
            product.copy(
                correctCount = product.correctCount + 1,
                lastPracticedAt = System.currentTimeMillis()
            )
        } else {
            product.copy(
                wrongCount = product.wrongCount + 1,
                lastPracticedAt = System.currentTimeMillis()
            )
        }
        dao.update(updated)
    }

    /**
     * Learning algorithm: selects a product weighted by learning need.
     * Items with errors or not yet learned have a much higher probability of being chosen.
     */
    fun selectNextPracticeProduct(
        allProducts: List<PluProduct>,
        currentProductId: Long? = null
    ): PluProduct? {
        if (allProducts.isEmpty()) return null
        if (allProducts.size == 1) return allProducts.first()

        // Filter out current product if we have more than 1 option
        val pool = allProducts.filter { it.id != currentProductId }
        val candidatePool = if (pool.isNotEmpty()) pool else allProducts

        val totalWeight = candidatePool.sumOf { it.practiceWeight }
        var randomVal = Random.nextDouble() * totalWeight

        for (product in candidatePool) {
            randomVal -= product.practiceWeight
            if (randomVal <= 0) {
                return product
            }
        }
        return candidatePool.first()
    }

    suspend fun seedSampleProducts() {
        val sampleList = listOf(
            PluProduct(plu = "4011", name = "Bananen", category = "Obst", emoji = "🍌"),
            PluProduct(plu = "4133", name = "Äpfel Gala", category = "Obst", emoji = "🍎"),
            PluProduct(plu = "4046", name = "Avocado Hass", category = "Gemüse", emoji = "🥑"),
            PluProduct(plu = "4030", name = "Kiwi grün", category = "Obst", emoji = "🥝"),
            PluProduct(plu = "4062", name = "Salatgurke", category = "Gemüse", emoji = "🥒"),
            PluProduct(plu = "4087", name = "Rispentomaten", category = "Gemüse", emoji = "🍅"),
            PluProduct(plu = "4060", name = "Brokkoli", category = "Gemüse", emoji = "🥦"),
            PluProduct(plu = "4053", name = "Zitronen", category = "Obst", emoji = "🍋"),
            PluProduct(plu = "4072", name = "Kartoffeln vorw. festkochend", category = "Gemüse", emoji = "🥔"),
            PluProduct(plu = "4088", name = "Paprika rot", category = "Gemüse", emoji = "🫑"),
            PluProduct(plu = "4065", name = "Paprika grün", category = "Gemüse", emoji = "🫑"),
            PluProduct(plu = "4069", name = "Weißkohl", category = "Gemüse", emoji = "🥬"),
            PluProduct(plu = "4079", name = "Blumenkohl", category = "Gemüse", emoji = "🥦"),
            PluProduct(plu = "4032", name = "Wassermelone", category = "Obst", emoji = "🍉"),
            PluProduct(plu = "4048", name = "Limetten", category = "Obst", emoji = "🍈"),
            PluProduct(plu = "4225", name = "Avocado groß", category = "Gemüse", emoji = "🥑"),
            PluProduct(plu = "4068", name = "Zwiebeln gelb", category = "Gemüse", emoji = "🧅"),
            PluProduct(plu = "4080", name = "Spargel weiß", category = "Gemüse", emoji = "🌱"),
            PluProduct(plu = "4383", name = "Mango essreif", category = "Obst", emoji = "🥭"),
            PluProduct(plu = "4029", name = "Ananas extra süß", category = "Obst", emoji = "🍍")
        )
        dao.insertAll(sampleList)
    }
}
