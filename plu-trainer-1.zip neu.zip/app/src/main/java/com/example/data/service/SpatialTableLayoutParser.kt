package com.example.data.service

import com.example.data.model.RecognizedPluItem
import com.example.data.model.SpatialBoundingBox
import java.util.regex.Pattern

data class SpatialTextBlock(
    val text: String,
    val x: Double,
    val y: Double,
    val width: Double = 0.0,
    val height: Double = 0.0
)

object SpatialTableLayoutParser {

    private val PAGE_NUMBER_PATTERN = Pattern.compile("(?i)\\b(seite|page|p\\.)\\s*\\d*(\\s*[/\\\\-]\\s*\\d+)?\\b")
    private val DATE_PATTERN = Pattern.compile("(?i)\\b(\\d{1,2}\\.\\d{1,2}\\.(\\d{2,4})?|kw\\s*\\d+|woche\\s*\\d+)\\b")
    private val PERCENT_PATTERN = Pattern.compile("(?i)[+-]?\\d+\\s*%")
    private val PRICE_PATTERN = Pattern.compile("(?i)(\\d+[.,]\\d{2}\\s*(€|EUR|ct)?|€\\s*\\d+[.,]\\d{2}|\\b\\d+[.,]\\d{2}\\b)")
    private val WEIGHT_QUANTITY_PATTERN = Pattern.compile("(?i)\\b(\\d*\\s*(kg|g|mg|l|ml|stk|stück|st|bund|schale|netz|beutel|fl|flasche|pck|packung|dose))\\b")
    private val EAN_BARCODE_PATTERN = Pattern.compile("\\b\\d{13}\\b")
    private val STOPWORDS = setOf("seite", "page", "angebote", "aktion", "artikel", "plu", "preis", "liste", "stand", "datum", "kw")

    /**
     * Parses multiline OCR text or tabular formatted text.
     * Supports single column lists, multi-column tables,
     * and filters out prices, weights, dates, and non-PLU numbers.
     */
    fun parseText(rawText: String): List<RecognizedPluItem> {
        val lines = rawText.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val results = mutableListOf<RecognizedPluItem>()

        for ((lineIndex, rawLine) in lines.withIndex()) {
            val lineItems = parseSingleLineOrMultiColumns(rawLine, lineIndex)
            results.addAll(lineItems)
        }

        return results
    }

    /**
     * Splits a single line into possible multiple columns (e.g. "Apfel 1234 | Banane 5678")
     * and extracts name -> PLU pairs.
     */
    private fun parseSingleLineOrMultiColumns(line: String, lineIndex: Int): List<RecognizedPluItem> {
        // If line contains explicit column pipe separators
        if (line.contains("|")) {
            val segments = line.split("|").map { it.trim() }.filter { it.isNotBlank() }
            return segments.mapIndexedNotNull { colIdx, seg ->
                extractItemFromSegment(seg, lineIndex, colIdx + 1)
            }
        }

        if (line.contains("\t")) {
            val segments = line.split("\t").map { it.trim() }.filter { it.isNotBlank() }
            return segments.mapIndexedNotNull { colIdx, seg ->
                extractItemFromSegment(seg, lineIndex, colIdx + 1)
            }
        }

        // Try extracting whole line as a single item first
        val singleItem = extractItemFromSegment(line, lineIndex, 1)
        if (singleItem != null) {
            return listOf(singleItem)
        }

        // If whole line didn't produce an item, attempt splitting by wide whitespace gaps
        if (line.contains("    ")) {
            val segments = line.split(Regex(" {4,}")).map { it.trim() }.filter { it.isNotBlank() }
            val items = segments.mapIndexedNotNull { colIdx, seg ->
                extractItemFromSegment(seg, lineIndex, colIdx + 1)
            }
            if (items.isNotEmpty()) {
                return items
            }
        }

        return emptyList()
    }

    /**
     * Extracts a single product name and PLU from a text segment.
     */
    fun extractItemFromSegment(segment: String, lineIndex: Int = 0, columnIndex: Int = 1): RecognizedPluItem? {
        var cleanSegment = segment

        // 1. Remove non-PLU noise tokens like page numbers, dates, prices, weights first
        cleanSegment = PAGE_NUMBER_PATTERN.matcher(cleanSegment).replaceAll(" ")
        cleanSegment = DATE_PATTERN.matcher(cleanSegment).replaceAll(" ")
        cleanSegment = PERCENT_PATTERN.matcher(cleanSegment).replaceAll(" ")
        cleanSegment = PRICE_PATTERN.matcher(cleanSegment).replaceAll(" ")
        cleanSegment = WEIGHT_QUANTITY_PATTERN.matcher(cleanSegment).replaceAll(" ")
        cleanSegment = EAN_BARCODE_PATTERN.matcher(cleanSegment).replaceAll(" ")

        // Replace slashes or punctuation noise
        cleanSegment = cleanSegment.replace("/", " ").replace("\\", " ")

        // Split remaining tokens
        val tokens = cleanSegment.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return null

        // Find candidate PLU tokens (pure digits, length 2 to 6)
        val pluCandidates = mutableListOf<IndexedValue<String>>()
        for ((idx, token) in tokens.withIndex()) {
            val cleanToken = token.trim()
                .removeSurrounding("(", ")")
                .removeSurrounding("[", "]")
                .removeSurrounding(":", "")
                .removePrefix("#")

            if (cleanToken.matches(Regex("^\\d{2,6}$"))) {
                pluCandidates.add(IndexedValue(idx, cleanToken))
            }
        }

        if (pluCandidates.isEmpty()) {
            // No PLU found in this segment
            return null
        }

        // Usually PLU is at the end or right after the product name
        val chosenPlu = pluCandidates.last()
        val nameTokens = tokens.filterIndexed { index, _ -> index != chosenPlu.index }
            .filter { it.lowercase() !in STOPWORDS }
        val productName = nameTokens.joinToString(" ").trim().removeSuffix("-").removeSuffix(":").trim()

        if (productName.isBlank()) {
            return null
        }

        // Calculate confidence
        var confidence = 0.95
        if (pluCandidates.size > 1) {
            confidence = 0.70
        }
        if (productName.length < 3) {
            confidence = 0.55
        }
        if (chosenPlu.value.length < 3) {
            confidence = 0.65
        }

        val emoji = getEmojiForProduct(productName)
        val category = determineCategory(productName)

        return RecognizedPluItem(
            name = productName,
            plu = chosenPlu.value, // Preserves leading zeroes exactly as String
            category = category,
            emoji = emoji,
            confidence = confidence,
            boundingBox = SpatialBoundingBox(
                top = lineIndex.toDouble(),
                bottom = lineIndex + 1.0,
                left = (columnIndex - 1) * 0.5,
                right = columnIndex * 0.5,
                column = columnIndex
            )
        )
    }

    /**
     * Parses spatially aware 2D text blocks by clustering into rows (Y) and columns (X).
     */
    fun parseSpatialBlocks(blocks: List<SpatialTextBlock>, yTolerance: Double = 20.0): List<RecognizedPluItem> {
        if (blocks.isEmpty()) return emptyList()

        // 1. Group blocks into horizontal lines (by Y coordinate within tolerance)
        val sortedByY = blocks.sortedBy { it.y }
        val lines = mutableListOf<MutableList<SpatialTextBlock>>()

        for (block in sortedByY) {
            val matchingLine = lines.find { line ->
                val lineAvgY = line.map { it.y }.average()
                Math.abs(lineAvgY - block.y) <= yTolerance
            }

            if (matchingLine != null) {
                matchingLine.add(block)
            } else {
                lines.add(mutableListOf(block))
            }
        }

        val recognizedItems = mutableListOf<RecognizedPluItem>()

        // Determine if there are multiple column clusters across the page
        val allX = blocks.map { it.x }
        val minX = allX.minOrNull() ?: 0.0
        val maxX = allX.maxOrNull() ?: 1.0
        val midX = (minX + maxX) / 2.0
        val isMultiColumn = maxX - minX > 200.0 && blocks.any { it.x < midX } && blocks.any { it.x >= midX }

        for ((lineIdx, lineBlocks) in lines.withIndex()) {
            // Sort line blocks horizontally (left to right)
            val sortedLine = lineBlocks.sortedBy { it.x }

            if (isMultiColumn) {
                // Split line into column 1 (left) and column 2 (right)
                val leftBlocks = sortedLine.filter { it.x < midX }
                val rightBlocks = sortedLine.filter { it.x >= midX }

                matchLineBlocksToItem(leftBlocks, lineIdx, column = 1)?.let { recognizedItems.add(it) }
                matchLineBlocksToItem(rightBlocks, lineIdx, column = 2)?.let { recognizedItems.add(it) }
            } else {
                matchLineBlocksToItem(sortedLine, lineIdx, column = 1)?.let { recognizedItems.add(it) }
            }
        }

        return recognizedItems
    }

    private fun matchLineBlocksToItem(blocks: List<SpatialTextBlock>, lineIndex: Int, column: Int): RecognizedPluItem? {
        if (blocks.isEmpty()) return null

        val fullText = blocks.joinToString(" ") { it.text }
        return extractItemFromSegment(fullText, lineIndex, column)
    }

    fun getEmojiForProduct(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.contains("apfel") || lower.contains("äpfel") || lower.contains("gala") || lower.contains("elstar") || lower.contains("braeburn") || lower.contains("jonagold") -> "🍎"
            lower.contains("banan") -> "🍌"
            lower.contains("avocado") || lower.contains("hass") -> "🥑"
            lower.contains("kiwi") -> "🥝"
            lower.contains("gurk") || lower.contains("salatgurke") -> "🥒"
            lower.contains("tomat") || lower.contains("rispe") || lower.contains("cherry") || lower.contains("fleischtomat") -> "🍅"
            lower.contains("kartoffel") || lower.contains("erdäpfel") -> "🥔"
            lower.contains("paprika") -> "🫑"
            lower.contains("kohl") || lower.contains("salat") || lower.contains("eisberg") || lower.contains("kopfsalat") -> "🥬"
            lower.contains("brokkoli") -> "🥦"
            lower.contains("zitrone") -> "🍋"
            lower.contains("limette") -> "🍈"
            lower.contains("zwiebel") || lower.contains("knoblauch") || lower.contains("lauch") || lower.contains("porree") -> "🧅"
            lower.contains("möhre") || lower.contains("karotte") || lower.contains("rübe") -> "🥕"
            lower.contains("orange") || lower.contains("mandarine") || lower.contains("clementine") -> "🍊"
            lower.contains("melone") || lower.contains("wassermelone") -> "🍉"
            lower.contains("ananas") -> "🍍"
            lower.contains("mango") -> "🥭"
            lower.contains("erdbeer") -> "🍓"
            lower.contains("himbeer") || lower.contains("heidelbeer") || lower.contains("blaubeer") -> "🫐"
            lower.contains("traub") || lower.contains("wein") -> "🍇"
            lower.contains("kirsch") -> "🍒"
            lower.contains("pfirsich") || lower.contains("nektarine") -> "🍑"
            lower.contains("birne") -> "🍐"
            lower.contains("pilz") || lower.contains("champignon") -> "🍄"
            lower.contains("brot") || lower.contains("brötchen") || lower.contains("weckerl") || lower.contains("semmel") -> "🥖"
            lower.contains("croissant") || lower.contains("hörnchen") -> "🥐"
            lower.contains("brezel") || lower.contains("laugen") -> "🥨"
            lower.contains("käse") || lower.contains("gouda") || lower.contains("emmentaler") -> "🧀"
            else -> "🏷️"
        }
    }

    fun determineCategory(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.contains("apfel") || lower.contains("äpfel") || lower.contains("banan") ||
                    lower.contains("kiwi") || lower.contains("zitrone") || lower.contains("orange") ||
                    lower.contains("mandarine") || lower.contains("melone") || lower.contains("ananas") ||
                    lower.contains("mango") || lower.contains("erdbeer") || lower.contains("traub") ||
                    lower.contains("kirsch") || lower.contains("pfirsich") || lower.contains("birne") ||
                    lower.contains("heidelbeer") || lower.contains("beere") -> "Obst"

            lower.contains("gurk") || lower.contains("tomat") || lower.contains("kartoffel") ||
                    lower.contains("paprika") || lower.contains("kohl") || lower.contains("salat") ||
                    lower.contains("brokkoli") || lower.contains("zwiebel") || lower.contains("knoblauch") ||
                    lower.contains("möhre") || lower.contains("karotte") || lower.contains("avocado") ||
                    lower.contains("pilz") || lower.contains("champignon") || lower.contains("lauch") ||
                    lower.contains("spinat") || lower.contains("zucchini") || lower.contains("aubergine") -> "Gemüse"

            lower.contains("brot") || lower.contains("brötchen") || lower.contains("baguette") ||
                    lower.contains("croissant") || lower.contains("brezel") || lower.contains("laugen") ||
                    lower.contains("krapfen") || lower.contains("weckerl") || lower.contains("semmel") -> "Backwaren"

            else -> "Obst & Gemüse"
        }
    }
}
