package com.example.data.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.RecognizedPluItem
import com.example.data.model.SpatialBoundingBox
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

sealed class RecognitionResult {
    data class Success(val items: List<RecognizedPluItem>) : RecognitionResult()
    data class Error(val userMessage: String, val details: String? = null) : RecognitionResult()
}

class PluRecognitionService(private val context: Context) {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun analyzeImageUris(uris: List<Uri>): RecognitionResult = withContext(Dispatchers.IO) {
        val bitmaps = mutableListOf<Bitmap>()
        for (uri in uris) {
            val bitmap = loadAndOrientBitmap(uri)
            if (bitmap != null) {
                bitmaps.add(bitmap)
            } else {
                Log.e("PluRecognition", "Failed to decode bitmap from uri: $uri")
            }
        }

        if (bitmaps.isEmpty()) {
            return@withContext RecognitionResult.Error(
                "Das ausgewählte Bild konnte nicht geladen werden. Bitte versuche es erneut."
            )
        }

        val allItems = mutableListOf<RecognizedPluItem>()
        val errors = mutableListOf<RecognitionResult.Error>()

        for (bitmap in bitmaps) {
            when (val result = analyzeSingleBitmap(bitmap)) {
                is RecognitionResult.Success -> allItems.addAll(result.items)
                is RecognitionResult.Error -> errors.add(result)
            }
        }

        if (allItems.isEmpty()) {
            // If Gemini/API itself failed, show that real error instead of pretending
            // that the photos contained no PLUs. This is especially important for
            // rate-limit/quota errors when several images are selected.
            if (errors.isNotEmpty()) {
                return@withContext errors.first()
            }
            return@withContext RecognitionResult.Error(
                "Es wurden keine PLU-Nummern auf den Bildern erkannt. Bitte achte auf ein scharfes, gut ausgeleuchtetes Foto der Liste."
            )
        }

        // A PLU may only occur once in one import batch. If Gemini reads the same
        // PLU more than once (for example from duplicate photos or slightly different
        // product text), keep the result with the highest confidence.
        val uniqueItems = allItems
            .groupBy { it.plu.trim() }
            .mapNotNull { (_, items) -> items.maxByOrNull { it.confidence } }

        RecognitionResult.Success(uniqueItems)
    }

    suspend fun analyzeSingleBitmap(bitmap: Bitmap): RecognitionResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("PluRecognition", "No Gemini API key configured in Secrets/BuildConfig")
            return@withContext RecognitionResult.Error(
                "Kein Gemini API-Schlüssel hinterlegt. Bitte trage deinen GEMINI_API_KEY im Secrets-Menü von AI Studio ein, um echte Fotos analysieren zu können."
            )
        }

        try {
            // Resize bitmap to optimal balance of high OCR clarity and payload efficiency
            val scaledBitmap = scaleBitmapIfNeeded(bitmap, maxDimension = 2048)
            val base64Image = bitmapToBase64(scaledBitmap)

            val systemInstruction = """
                Du bist eine hochspezialisierte OCR- und Spatial-Layout-Engine für Supermarkt- und Kassen-PLU-Listen.
                Deine Kernaufgabe: Analysiere das Bild und ordne jeden Produktnamen exakt der räumlich zugehörigen PLU-Nummer zu.

                WICHTIGE REGELN FÜR DIE RÄUMLICHE ZUORDNUNG & TABELLEN:
                1. RÄUMLICHE NÄHE & ZEILEN:
                   - Eine PLU-Nummer gehört zwingend zu dem Produkt in derselben Zeile (gleiche vertikale Y-Höhe).
                   - Achte auf MEHRERE SPALTEN (z.B. links Spalte 1: Produkt + PLU, rechts Spalte 2: Produkt + PLU).
                   - Vertausche niemals Spalten! Eine PLU aus Spalte 2 darf NIEMALS einem Produkt aus Spalte 1 zugeordnet werden.
                
                2. PLU-NUMMERN ALS REINER TEXT:
                   - Behandle PLU-Nummern ausnahmslos als Text (String).
                   - Führende Nullen dürfen NIEMALS verloren gehen (z.B. '0413', '007', '0214', '94011', '3152').
                   - Akzeptiere beliebige PLU-Längen (z.B. 2 bis 6 Ziffern oder alphanumerische Codes).

                3. STRIKTER AUSSCHLUSS VON ANDEREN ZAHLEN:
                   - Filter Preise (z.B. 1,99 €, 2.49, 0,89 €/kg, 3.50 EUR). Preise sind KEINE PLU!
                   - Filter Mengenangaben und Gewichte (z.B. 1kg, 500g, 1 Stk, 100ml, Bund, Beutel).
                   - Filter Datumsangaben (z.B. 12.04., KW 15), Seitenzahlen (Seite 1), Prozentwerte (-20%) und 13-stellige EAN-Barcodes.

                4. CONFIDENCE BEWERTUNG:
                   - 0.85 bis 1.00 = "Sicher" (glasklare Zeilenzuordnung, scharfer Text).
                   - 0.60 bis 0.84 = "Wahrscheinlich" (z.B. leichte Schräglage oder kleiner Abstand).
                   - unter 0.60 = "Unsicher" (unklare Zeilenzuordnung, mehrere Zahlen nahe beieinander, abgeschnittener Text).
                   - Wenn keine sinnvolle Zuordnung möglich ist: NICHT raten, sondern weglassen.

                5. ANTWORTFORMAT:
                   Antworte AUSSCHLIESSLICH im validen JSON-Format als Array von Objekten mit folgenden Schlüsseln:
                   - "name": String (vollständiger Produktname, z.B. "Apfel Gala", "Bio Bananen")
                   - "plu": String (PLU-Nummer als Text inklusive führender Nullen, z.B. "0413", "4011")
                   - "category": String ("Obst", "Gemüse", "Backwaren", etc.)
                   - "emoji": String (passendes Emoji wie 🍎, 🍌, 🥐, etc.)
                   - "confidence": Number (zwischen 0.0 und 1.0)
                   - "column": Number (1 für linke Spalte, 2 für rechte Spalte etc.)

                Beispiel:
                [
                  {"name": "Apfel Gala", "plu": "1234", "category": "Obst", "emoji": "🍎", "confidence": 0.98, "column": 1},
                  {"name": "Bio Bananen", "plu": "0413", "category": "Obst", "emoji": "🍌", "confidence": 0.95, "column": 1}
                ]
                Gib ausschließlich Produkte zurück, die tatsächlich auf dem Bild zu sehen sind. Falls gar keine PLUs erkennbar sind, gib ein leeres JSON-Array [] zurück.
            """.trimIndent()

            val prompt = "Analysiere dieses Bild. Extrahiere alle sichtbaren Produkte und ihre zugehörigen PLU-Nummern unter strikter Beachtung der räumlichen Zeilen- und Spaltenzuordnung."

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemInstruction)
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.05)
                    put("responseMimeType", "application/json")
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val modelName = "gemini-3.6-flash"
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBodyString = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e("PluRecognition", "Gemini API call failed with status ${response.code}: $responseBodyString")
                val extractedMessage = try {
                    val errJson = JSONObject(responseBodyString)
                    errJson.optJSONObject("error")?.optString("message")
                } catch (e: Exception) {
                    null
                } ?: "HTTP Fehler ${response.code}"

                val userMessage = when (response.code) {
                    429 -> "Das KI-Limit ist gerade erreicht. Bitte warte kurz und versuche die Bildanalyse danach erneut."
                    401, 403 -> "Der Gemini API-Schlüssel wurde abgelehnt. Bitte prüfe den hinterlegten API-Schlüssel."
                    else -> "Die KI-Bilderkennung konnte gerade nicht durchgeführt werden. Bitte versuche es erneut."
                }

                return@withContext RecognitionResult.Error(
                    userMessage = userMessage,
                    details = extractedMessage
                )
            }

            val jsonObject = JSONObject(responseBodyString)
            val candidates = jsonObject.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawResponseText = parts?.optJSONObject(0)?.optString("text") ?: ""

            val recognizedItems = parseGeminiJsonResponse(rawResponseText)
            if (recognizedItems.isEmpty()) {
                return@withContext RecognitionResult.Error(
                    "Auf dem hochgeladenen Foto konnten keine PLU-Nummern oder Produkte erkannt werden. Bitte versuche ein schärferes, frontales Bild."
                )
            }

            RecognitionResult.Success(recognizedItems)
        } catch (e: Exception) {
            Log.e("PluRecognition", "Error during Gemini recognition", e)
            RecognitionResult.Error(
                "Fehler bei der Bildanalyse: ${e.localizedMessage ?: e.message ?: "Unbekannter Fehler"}. Bitte prüfe die Internetverbindung."
            )
        }
    }

    fun parseGeminiJsonResponse(rawJson: String): List<RecognizedPluItem> {
        val list = mutableListOf<RecognizedPluItem>()
        try {
            var clean = rawJson.trim()
            if (clean.startsWith("```json")) {
                clean = clean.removePrefix("```json")
            }
            if (clean.startsWith("```")) {
                clean = clean.removePrefix("```")
            }
            if (clean.endsWith("```")) {
                clean = clean.removeSuffix("```")
            }
            clean = clean.trim()

            if (!clean.startsWith("[") && !clean.startsWith("{")) {
                // If Gemini responded with raw text or table lines instead of strict JSON, parse using spatial parser
                return SpatialTableLayoutParser.parseText(clean)
            }

            val array = if (clean.startsWith("[")) {
                JSONArray(clean)
            } else {
                val obj = JSONObject(clean)
                obj.optJSONArray("products") ?: obj.optJSONArray("items") ?: JSONArray()
            }

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val name = item.optString("name", "").trim()
                var plu = item.optString("plu", "").trim()
                val category = item.optString("category", "").trim().ifBlank { SpatialTableLayoutParser.determineCategory(name) }
                val emoji = item.optString("emoji", "").trim().ifBlank { SpatialTableLayoutParser.getEmojiForProduct(name) }
                val confidence = item.optDouble("confidence", 0.95)
                val column = item.optInt("column", 1)

                // Clean PLU token to remove accidental non-digit characters while strictly keeping leading zeroes
                val cleanedPlu = plu.filter { it.isDigit() }
                if (cleanedPlu.isNotEmpty()) {
                    plu = cleanedPlu
                }

                if (name.isNotBlank() && plu.isNotBlank()) {
                    list.add(
                        RecognizedPluItem(
                            name = name,
                            plu = plu, // Preserves exact string representation
                            category = category,
                            emoji = emoji,
                            confidence = confidence.coerceIn(0.0, 1.0),
                            boundingBox = SpatialBoundingBox(
                                top = i.toDouble(),
                                bottom = i + 1.0,
                                column = column
                            )
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("PluRecognition", "Failed to parse JSON directly, falling back to line parser: $rawJson", e)
            return SpatialTableLayoutParser.parseText(rawJson)
        }
        return list
    }

    private fun loadAndOrientBitmap(uri: Uri): Bitmap? {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val originalBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

            val exif = try {
                ExifInterface(bytes.inputStream())
            } catch (e: Exception) {
                null
            }

            val orientation = exif?.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            ) ?: ExifInterface.ORIENTATION_NORMAL

            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            }

            if (!matrix.isIdentity) {
                Bitmap.createBitmap(originalBitmap, 0, 0, originalBitmap.width, originalBitmap.height, matrix, true)
            } else {
                originalBitmap
            }
        } catch (e: Exception) {
            Log.e("PluRecognition", "Error reading and orienting bitmap for URI: $uri", e)
            null
        }
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) {
            return bitmap
        }
        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDimension
            newHeight = (maxDimension / ratio).toInt()
        } else {
            newHeight = maxDimension
            newWidth = (maxDimension * ratio).toInt()
        }
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
