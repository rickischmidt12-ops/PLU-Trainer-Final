package com.example.data.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import com.example.data.model.RecognizedPluItem
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

sealed class RecognitionResult {
    data class Success(val items: List<RecognizedPluItem>) : RecognitionResult()
    data class Error(val userMessage: String, val details: String? = null) : RecognitionResult()
}

/**
 * Local PLU recognition using the bundled ML Kit Latin text recognizer.
 *
 * No image or text is sent to Gemini or another paid AI API. Recognition runs
 * on the device, so there is no shared API quota that users can exhaust.
 */
class PluRecognitionService(private val context: Context) {

    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun analyzeImageUris(uris: List<Uri>): RecognitionResult = withContext(Dispatchers.IO) {
        val bitmaps = uris.mapNotNull { uri ->
            loadAndOrientBitmap(uri).also { bitmap ->
                if (bitmap == null) Log.e("PluRecognition", "Failed to decode bitmap from uri: $uri")
            }
        }

        if (bitmaps.isEmpty()) {
            return@withContext RecognitionResult.Error(
                "Das ausgewählte Bild konnte nicht geladen werden. Bitte versuche es erneut."
            )
        }

        val allItems = mutableListOf<RecognizedPluItem>()
        val errors = mutableListOf<RecognitionResult.Error>()

        for (bitmap in bitmaps) {
            when (val result = analyzeSingleBitmap(bitmap)) {
                is RecognitionResult.Success -> allItems.addAll(result.items)
                is RecognitionResult.Error -> errors.add(result)
            }
        }

        if (allItems.isEmpty()) {
            return@withContext errors.firstOrNull() ?: RecognitionResult.Error(
                "Es wurden keine PLU-Nummern auf den Bildern erkannt. Bitte achte auf ein scharfes, gut ausgeleuchtetes und möglichst frontales Foto der Liste."
            )
        }

        // A PLU may occur only once in a single import batch. Keep the result
        // with the highest confidence if the same PLU was read multiple times.
        val uniqueItems = allItems
            .groupBy { it.plu.trim() }
            .mapNotNull { (_, items) -> items.maxByOrNull { it.confidence } }

        RecognitionResult.Success(uniqueItems)
    }

    suspend fun analyzeSingleBitmap(bitmap: Bitmap): RecognitionResult = withContext(Dispatchers.IO) {
        try {
            // V3: run OCR in several local passes. Laminated/creased PLU lists often
            // contain shadows or bright reflections. One OCR pass can silently miss
            // otherwise valid rows, so we also scan two contrast-enhanced variants.
            // Everything still runs locally on the phone; no API/quota is involved.
            val scaledBitmap = scaleBitmapIfNeeded(bitmap, maxDimension = 3000)
            val variants = listOf(
                scaledBitmap,
                createOcrVariant(scaledBitmap, contrast = 1.28f, brightness = 8f, saturation = 0f),
                createOcrVariant(scaledBitmap, contrast = 1.55f, brightness = 18f, saturation = 0f)
            )

            val candidates = mutableListOf<RecognizedPluItem>()
            for ((passIndex, variant) in variants.withIndex()) {
                val visionText = recognizeText(InputImage.fromBitmap(variant, 0))
                val passItems = parseRecognizedText(visionText).map { item ->
                    // Prefer the untouched image when two passes found the same row,
                    // but keep rows that only become visible after enhancement.
                    val penalty = passIndex * 0.015
                    item.copy(confidence = (item.confidence - penalty).coerceAtLeast(0.50))
                }
                candidates.addAll(passItems)
            }

            val items = candidates
                .groupBy { it.plu.trim() }
                .mapNotNull { (_, matches) -> matches.maxByOrNull { it.confidence } }

            if (items.isEmpty()) {
                return@withContext RecognitionResult.Error(
                    "Auf dem Foto konnten keine eindeutigen Produkt-/PLU-Zeilen erkannt werden. Bitte fotografiere die Liste scharf, gerade und mit guter Beleuchtung."
                )
            }

            RecognitionResult.Success(items)
        } catch (e: Exception) {
            Log.e("PluRecognition", "Local OCR failed", e)
            RecognitionResult.Error(
                "Fehler bei der lokalen Bilderkennung: ${e.localizedMessage ?: e.message ?: "Unbekannter Fehler"}. Bitte versuche es mit einem anderen Foto erneut."
            )
        }
    }

    private suspend fun recognizeText(image: InputImage): Text = suspendCoroutine { continuation ->
        textRecognizer.process(image)
            .addOnSuccessListener { result -> continuation.resume(result) }
            .addOnFailureListener { error -> continuation.resumeWith(Result.failure(error)) }
    }

    /**
     * Prefer ML Kit's own line grouping because it usually preserves table rows
     * better than rebuilding rows from individual words. If that does not yield
     * enough pairs, fall back to the existing spatial and plain-text parsers.
     */
    private fun parseRecognizedText(visionText: Text): List<RecognizedPluItem> {
        val directLineItems = mutableListOf<RecognizedPluItem>()
        val spatialBlocks = mutableListOf<SpatialTextBlock>()

        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val lineText = line.text.trim()
                if (lineText.isNotBlank()) {
                    SpatialTableLayoutParser.extractItemFromSegment(lineText)?.let { item ->
                        directLineItems.add(item)
                    }
                }

                // Individual elements retain X/Y positions for a fallback when
                // the product name and PLU are emitted as separate OCR pieces.
                for (element in line.elements) {
                    val box = element.boundingBox ?: continue
                    val text = element.text.trim()
                    if (text.isBlank()) continue
                    spatialBlocks.add(
                        SpatialTextBlock(
                            text = text,
                            x = box.left.toDouble(),
                            y = box.centerY().toDouble(),
                            width = box.width().toDouble(),
                            height = box.height().toDouble()
                        )
                    )
                }
            }
        }

        val spatialItems = if (spatialBlocks.isNotEmpty()) {
            val averageHeight = spatialBlocks.map { it.height }.filter { it > 0.0 }.average()
            val tolerance = if (averageHeight.isNaN()) 18.0 else (averageHeight * 0.65).coerceIn(12.0, 45.0)
            SpatialTableLayoutParser.parseSpatialBlocks(spatialBlocks, yTolerance = tolerance)
        } else {
            emptyList()
        }

        val plainTextItems = SpatialTableLayoutParser.parseText(visionText.text)

        // V4: PLU-anchor recovery. A valid four-digit PLU is strong evidence that
        // a table row exists even when ML Kit split the product name and number
        // into separate pieces. Start from every 4-digit OCR element, then attach
        // text from the same visual row. This avoids silently dropping readable
        // PLUs just because normal line reconstruction failed.
        val anchoredItems = recoverItemsFromFourDigitAnchors(spatialBlocks)

        // Merge all strategies, then deduplicate by PLU. Direct ML Kit line
        // results get a small confidence advantage because row grouping came
        // directly from the recognizer rather than being reconstructed.
        val merged = buildList {
            addAll(directLineItems.map { it.copy(confidence = (it.confidence + 0.03).coerceAtMost(0.99)) })
            addAll(spatialItems)
            addAll(anchoredItems)
            addAll(plainTextItems.map { it.copy(confidence = (it.confidence - 0.05).coerceAtLeast(0.50)) })
        }

        return merged
            .filter { it.name.isNotBlank() && it.plu.matches(Regex("^\\d{2,6}$")) }
            .groupBy { it.plu }
            .mapNotNull { (_, candidates) -> candidates.maxByOrNull { it.confidence } }
    }


    /** V4 fallback: recover rows by treating every isolated 4-digit token as a PLU anchor. */
    private fun recoverItemsFromFourDigitAnchors(blocks: List<SpatialTextBlock>): List<RecognizedPluItem> {
        if (blocks.isEmpty()) return emptyList()
        val heights = blocks.map { it.height }.filter { it > 0.0 }
        val avgHeight = if (heights.isEmpty()) 20.0 else heights.average()
        val yTolerance = (avgHeight * 0.70).coerceIn(10.0, 42.0)

        val rows = mutableListOf<MutableList<SpatialTextBlock>>()
        for (block in blocks.sortedBy { it.y }) {
            val row = rows.minByOrNull { kotlin.math.abs(it.map { b -> b.y }.average() - block.y) }
            if (row != null && kotlin.math.abs(row.map { it.y }.average() - block.y) <= yTolerance) row.add(block)
            else rows.add(mutableListOf(block))
        }

        val results = mutableListOf<RecognizedPluItem>()
        for ((rowIndex, row) in rows.withIndex()) {
            val sorted = row.sortedBy { it.x }
            val anchors = sorted.filter { it.text.trim().matches(Regex("^\\d{4}$")) }
            if (anchors.isEmpty()) continue

            for ((anchorIndex, anchor) in anchors.withIndex()) {
                val previous = anchors.getOrNull(anchorIndex - 1)
                val next = anchors.getOrNull(anchorIndex + 1)
                val leftBound = previous?.let { (it.x + anchor.x) / 2.0 } ?: Double.NEGATIVE_INFINITY
                val rightBound = next?.let { (anchor.x + it.x) / 2.0 } ?: Double.POSITIVE_INFINITY
                val zone = sorted.filter { it.x >= leftBound && it.x < rightBound && it !== anchor }

                // Product text is normally beside the PLU. Keep all non-header text
                // in the anchor's row/column, including useful quantities like 500/600g.
                val name = zone.joinToString(" ") { it.text.trim() }
                    .replace(Regex("(?i)\\bPLU\\b"), " ")
                    .replace(Regex("(?i)\\b(STUECKARTIKEL|STÜCKARTIKEL|GEWICHTSARTIKEL)\\b"), " ")
                    .replace(Regex("\\s+"), " ").trim()
                if (name.length < 2 || name.matches(Regex("^\\d+$"))) continue

                results.add(RecognizedPluItem(
                    name = name,
                    plu = anchor.text.trim(),
                    category = SpatialTableLayoutParser.determineCategory(name),
                    emoji = SpatialTableLayoutParser.getEmojiForProduct(name),
                    confidence = 0.82,
                    boundingBox = SpatialBoundingBox(
                        top = anchor.y - anchor.height / 2.0,
                        bottom = anchor.y + anchor.height / 2.0,
                        left = anchor.x,
                        right = anchor.x + anchor.width,
                        column = anchorIndex + 1
                    ),
                    contextNote = "V4: aus 4-stelliger PLU-Zeile rekonstruiert"
                ))
            }
        }
        return results
    }

    /**
     * Creates a grayscale/contrast OCR copy. This is intentionally simple and
     * deterministic: it helps ML Kit read text through uneven illumination,
     * reflections and low-contrast paper without changing the user's photo.
     */
    private fun createOcrVariant(
        source: Bitmap,
        contrast: Float,
        brightness: Float,
        saturation: Float
    ): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val matrix = ColorMatrix().apply { setSaturation(saturation) }
        val translate = brightness + 128f * (1f - contrast)
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        matrix.postConcat(contrastMatrix)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrix)
            isFilterBitmap = true
        }
        canvas.drawBitmap(source, 0f, 0f, paint)
        return output
    }

    private fun loadAndOrientBitmap(uri: Uri): Bitmap? {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val originalBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

            val exif = try {
                ExifInterface(bytes.inputStream())
            } catch (_: Exception) {
                null
            }

            val orientation = exif?.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            ) ?: ExifInterface.ORIENTATION_NORMAL

            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            }

            if (!matrix.isIdentity) {
                Bitmap.createBitmap(
                    originalBitmap,
                    0,
                    0,
                    originalBitmap.width,
                    originalBitmap.height,
                    matrix,
                    true
                )
            } else {
                originalBitmap
            }
        } catch (e: Exception) {
            Log.e("PluRecognition", "Error reading and orienting bitmap for URI: $uri", e)
            null
        }
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap

        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDimension
            newHeight = (maxDimension / ratio).toInt()
        } else {
            newHeight = maxDimension
            newWidth = (maxDimension * ratio).toInt()
        }
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }
}
