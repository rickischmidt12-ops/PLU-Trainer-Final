package com.example.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object AddPhotos : Screen("add_photos")
    data object RecognitionResult : Screen("recognition_result")
    data object Practice : Screen("practice")
    data object ProductList : Screen("product_list")
    data object Settings : Screen("settings")
}
