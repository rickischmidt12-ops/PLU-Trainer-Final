package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DuplicateAction
import com.example.data.model.RecognitionConfidenceLevel
import com.example.data.model.RecognizedPluItem
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.OnMinimalPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.PluViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecognitionResultScreen(
    viewModel: PluViewModel,
    onNavigateBack: () -> Unit,
    onSavedSuccessfully: () -> Unit
) {
    val recognitionState by viewModel.recognitionState.collectAsStateWithLifecycle()
    val recognizedItems = recognitionState.recognizedItems
    val activeItemsToSaveCount = recognizedItems.count {
        it.name.isNotBlank() && it.plu.isNotBlank() &&
                !(it.isDuplicateOfExisting && it.duplicateAction == DuplicateAction.SKIP)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Erkannte Produkte",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 18.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "${recognizedItems.size} Produkte zur Prüfung",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                },
                navigationIcon = {
                    OutlinedButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .padding(start = 12.dp, end = 4.dp)
                            .testTag("btn_back_from_results"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Zurück",
                            tint = TextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Zurück",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                    }
                },
                actions = {
                    OutlinedButton(
                        onClick = { viewModel.addManualRecognizedItem() },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("btn_add_manual_row_top"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MinimalPurple.copy(alpha = 0.4f)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Hinzufügen",
                            tint = MinimalPurple,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Hinzufügen",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MinimalPurple
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        },
        bottomBar = {
            Surface(
                color = DarkSurface,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f))
                    ) {
                        Text(text = "Abbrechen", color = TextSecondary, fontWeight = FontWeight.Medium)
                    }

                    Button(
                        onClick = {
                            viewModel.saveAllRecognizedItems(onComplete = onSavedSuccessfully)
                        },
                        enabled = activeItemsToSaveCount > 0,
                        modifier = Modifier
                            .weight(2f)
                            .height(52.dp)
                            .testTag("btn_save_all_recognized"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            contentColor = Color.White,
                            disabledContainerColor = DarkSurfaceElevated,
                            disabledContentColor = TextMuted
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Alle speichern ($activeItemsToSaveCount)",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        },
        containerColor = DarkBackground
    ) { paddingValues ->
        if (recognizedItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Keine Einträge vorhanden",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Füge manuell ein Produkt hinzu oder scanne ein neues Foto.",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.addManualRecognizedItem() },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple, contentColor = OnMinimalPurple)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Produkt manuell hinzufügen", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MinimalPurple,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Bitte überprüfe die Zuordnungen. Namen und PLUs können frei editiert oder ergänzt werden.",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                items(recognizedItems, key = { it.tempId }) { item ->
                    RecognizedItemCard(
                        item = item,
                        onNameChange = { newName ->
                            viewModel.updateRecognizedItem(item.tempId, newName, item.plu, item.category)
                        },
                        onPluChange = { newPlu ->
                            viewModel.updateRecognizedItem(item.tempId, item.name, newPlu, item.category)
                        },
                        onDuplicateActionChange = { action ->
                            viewModel.updateRecognizedItemDuplicateAction(item.tempId, action)
                        },
                        onDelete = {
                            viewModel.removeRecognizedItem(item.tempId)
                        }
                    )
                }

                item {
                    OutlinedButton(
                        onClick = { viewModel.addManualRecognizedItem() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .testTag("btn_add_manual_row_bottom"),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, MinimalPurple.copy(alpha = 0.35f))
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = MinimalPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Produkt hinzufügen", color = MinimalPurple, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun RecognizedItemCard(
    item: RecognizedPluItem,
    onNameChange: (String) -> Unit,
    onPluChange: (String) -> Unit,
    onDuplicateActionChange: (DuplicateAction) -> Unit,
    onDelete: () -> Unit
) {
    val isUncertain = item.confidenceLevel == RecognitionConfidenceLevel.UNCERTAIN
    val isSkipped = item.isDuplicateOfExisting && item.duplicateAction == DuplicateAction.SKIP

    val cardBorderColor = when {
        isSkipped -> Color.White.copy(alpha = 0.04f)
        item.isDuplicateOfExisting -> WarningAmber.copy(alpha = 0.35f)
        isUncertain -> ErrorRed.copy(alpha = 0.45f)
        item.confidenceLevel == RecognitionConfidenceLevel.PROBABLE -> WarningAmber.copy(alpha = 0.25f)
        else -> Color.White.copy(alpha = 0.08f)
    }

    val cardAlpha = if (isSkipped) 0.55f else 1.0f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recognized_item_${item.tempId}")
            .border(1.dp, cardBorderColor, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUncertain) DarkSurfaceElevated else DarkSurface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Row: Status Badge & Confidence
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Confidence Status Badge
                ConfidenceBadge(confidenceLevel = item.confidenceLevel, score = item.confidence)

                // Delete Action Button
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("btn_delete_recognized_${item.tempId}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Eintrag löschen",
                        tint = ErrorRed.copy(alpha = 0.75f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // If duplicate found in database, show warning banner and 3 resolution options
            if (item.isDuplicateOfExisting) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = WarningAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Diese PLU (${item.plu}) ist bereits vorhanden.",
                                color = WarningAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        // Duplicate action selector
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DuplicateOptionChip(
                                label = "Aktualisieren",
                                isSelected = item.duplicateAction == DuplicateAction.UPDATE,
                                onClick = { onDuplicateActionChange(DuplicateAction.UPDATE) },
                                modifier = Modifier.weight(1f)
                            )
                            DuplicateOptionChip(
                                label = "Überspringen",
                                isSelected = item.duplicateAction == DuplicateAction.SKIP,
                                onClick = { onDuplicateActionChange(DuplicateAction.SKIP) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            } else if (isUncertain) {
                // Uncertain notice
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = null,
                        tint = ErrorRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Zuordnung unsicher – bitte Name & PLU prüfen",
                        color = ErrorRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Input Fields Row (Product Name + PLU)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Emoji Icon
                Surface(
                    shape = CircleShape,
                    color = DarkSurfaceElevated,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = item.emoji, fontSize = 22.sp)
                    }
                }

                // Product Name Field
                OutlinedTextField(
                    value = item.name,
                    onValueChange = onNameChange,
                    label = { Text("Produktname") },
                    placeholder = { Text("z.B. Apfel Gala") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1.8f)
                        .testTag("input_recognized_name_${item.tempId}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MinimalPurple,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                // PLU Field (Always strictly formatted as Text to preserve leading zeroes)
                OutlinedTextField(
                    value = item.plu,
                    onValueChange = { input ->
                        // Filter to keep digits only while preserving leading zeroes as text
                        val digitsOnly = input.filter { it.isDigit() }
                        onPluChange(digitsOnly)
                    },
                    label = { Text("PLU") },
                    placeholder = { Text("4011") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSkipped) TextMuted else MinimalPurple
                    ),
                    modifier = Modifier
                        .weight(1.1f)
                        .testTag("input_recognized_plu_${item.tempId}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MinimalPurple,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.12f),
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            }
        }
    }
}

@Composable
private fun ConfidenceBadge(confidenceLevel: RecognitionConfidenceLevel, score: Double) {
    val (badgeBg, badgeText, badgeIcon, label) = when (confidenceLevel) {
        RecognitionConfidenceLevel.SECURE -> Tuple4(
            SuccessGreen.copy(alpha = 0.15f),
            SuccessGreen,
            Icons.Default.CheckCircle,
            "Sicher"
        )
        RecognitionConfidenceLevel.PROBABLE -> Tuple4(
            WarningAmber.copy(alpha = 0.15f),
            WarningAmber,
            Icons.Default.Info,
            "Wahrscheinlich"
        )
        RecognitionConfidenceLevel.UNCERTAIN -> Tuple4(
            ErrorRed.copy(alpha = 0.15f),
            ErrorRed,
            Icons.Default.Warning,
            "Unsicher"
        )
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = badgeBg
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = badgeIcon,
                contentDescription = null,
                tint = badgeText,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$label (${(score * 100).toInt()}%)",
                color = badgeText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DuplicateOptionChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) WarningAmber else DarkSurfaceElevated,
        border = BorderStroke(1.dp, if (isSelected) WarningAmber else Color.White.copy(alpha = 0.1f)),
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.Black else TextSecondary
            )
        }
    }
}

private data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
