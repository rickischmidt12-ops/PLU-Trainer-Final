package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Theme Accents
val MinimalPurple = Color(0xFFD0BCFF)
val OnMinimalPurple = Color(0xFF381E72)
val MinimalPurpleContainer = Color(0xFF4F378B)
val OnMinimalPurpleContainer = Color(0xFFEADDFF)

// Vibrant Blue for Secondary Action
val PrimaryBlue = Color(0xFF3B82F6)
val PrimaryBlueVariant = Color(0xFF2563EB)
val PrimaryBlueLight = Color(0xFF93C5FD)
val PrimaryBlueContainer = Color(0xFF1E3A8A)
val OnPrimaryBlue = Color(0xFFFFFFFF)

// Secondary & Aux
val SecondaryCyan = Color(0xFF38BDF8)
val SecondaryCyanContainer = Color(0xFF0C4A6E)
val OnSecondaryCyan = Color(0xFFFFFFFF)

// Success (Green)
val SuccessGreen = Color(0xFF22C55E)
val SuccessGreenDark = Color(0xFF16A34A)
val SuccessGreenContainer = Color(0xFF14532D)
val OnSuccessGreen = Color(0xFFFFFFFF)

// Error (Red)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedDark = Color(0xFFDC2626)
val ErrorRedContainer = Color(0xFF7F1D1D)
val OnErrorRed = Color(0xFFFFFFFF)

// Warning / To Learn (Amber)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberContainer = Color(0xFF78350F)

// Clean Minimalism Dark Surfaces & Canvas
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceCard = Color(0xFF1E1E1E)
val DarkSurfaceElevated = Color(0xFF252525)
val DarkSurfaceTrack = Color(0xFF333333)
val DarkBorder = Color(0x1FFFFFFF) // 12% white
val DarkBorderSubtle = Color(0x0DFFFFFF) // 5% white

val TextPrimary = Color(0xFFE3E2E6)
val TextSecondary = Color(0x99FFFFFF) // 60% white
val TextMuted = Color(0x66FFFFFF) // 40% white

