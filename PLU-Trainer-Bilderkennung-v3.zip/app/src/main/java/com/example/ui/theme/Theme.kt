package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val PluDarkColorScheme = darkColorScheme(
    primary = MinimalPurple,
    onPrimary = OnMinimalPurple,
    primaryContainer = MinimalPurpleContainer,
    onPrimaryContainer = OnMinimalPurpleContainer,
    secondary = PrimaryBlue,
    onSecondary = OnPrimaryBlue,
    secondaryContainer = PrimaryBlueContainer,
    onSecondaryContainer = PrimaryBlueLight,
    tertiary = SuccessGreen,
    onTertiary = OnSuccessGreen,
    tertiaryContainer = SuccessGreenContainer,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerHighest = DarkSurfaceElevated,
    outline = DarkBorder,
    outlineVariant = DarkBorderSubtle,
    error = ErrorRed,
    onError = OnErrorRed,
    errorContainer = ErrorRedContainer
)

@Composable
fun PluTrainerTheme(
    darkTheme: Boolean = true, // Clean Minimalism Dark Theme
    content: @Composable () -> Unit
) {
    val colorScheme = PluDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

