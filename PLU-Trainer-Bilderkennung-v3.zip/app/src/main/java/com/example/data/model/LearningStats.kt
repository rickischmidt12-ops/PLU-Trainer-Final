package com.example.data.model

data class LearningStats(
    val totalProducts: Int = 0,
    val overallAccuracy: Int = 0,
    val toLearnCount: Int = 0,
    val masteredCount: Int = 0,
    val totalPracticed: Int = 0
)
