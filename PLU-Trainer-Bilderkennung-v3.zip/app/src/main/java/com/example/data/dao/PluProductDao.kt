package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PluProduct
import kotlinx.coroutines.flow.Flow

@Dao
interface PluProductDao {
    @Query("SELECT * FROM plu_products ORDER BY name COLLATE NOCASE ASC")
    fun getAllProducts(): Flow<List<PluProduct>>

    @Query("SELECT * FROM plu_products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Long): PluProduct?

    @Query("SELECT * FROM plu_products WHERE plu = :plu LIMIT 1")
    suspend fun getProductByPlu(plu: String): PluProduct?

    @Query("SELECT * FROM plu_products WHERE name LIKE '%' || :query || '%' OR plu LIKE '%' || :query || '%' ORDER BY name COLLATE NOCASE ASC")
    fun searchProducts(query: String): Flow<List<PluProduct>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: PluProduct): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(products: List<PluProduct>): List<Long>

    @Update
    suspend fun update(product: PluProduct)

    @Delete
    suspend fun delete(product: PluProduct)

    @Query("DELETE FROM plu_products WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM plu_products")
    suspend fun deleteAll()

    @Query("UPDATE plu_products SET correctCount = 0, wrongCount = 0, lastPracticedAt = NULL")
    suspend fun resetStats()

    @Query("SELECT COUNT(*) FROM plu_products")
    fun getProductCount(): Flow<Int>
}
