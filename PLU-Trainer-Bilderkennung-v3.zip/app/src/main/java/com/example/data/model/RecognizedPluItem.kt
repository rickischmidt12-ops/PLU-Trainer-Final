package com.example.data.model

import java.util.UUID

enum class RecognitionConfidenceLevel(val label: String) {
    SECURE("Sicher"),
    PROBABLE("Wahrscheinlich"),
    UNCERTAIN("Unsicher")
}

enum class DuplicateAction(val label: String) {
    UPDATE("Vorhandenen Eintrag aktualisieren"),
    KEEP_NEW("Als neues Produkt speichern"),
    SKIP("Überspringen")
}

data class SpatialBoundingBox(
    val top: Double = 0.0,
    val left: Double = 0.0,
    val bottom: Double = 0.0,
    val right: Double = 0.0,
    val column: Int = 1
)

data class RecognizedPluItem(
    val tempId: String = UUID.randomUUID().toString(),
    var name: String,
    var plu: String, // String to strictly preserve leading zeroes (e.g. "0413")
    var category: String = "Obst & Gemüse",
    var emoji: String = "🏷️",
    var confidence: Double = 0.95,
    var isDuplicateOfExisting: Boolean = false,
    var existingId: Long? = null,
    var duplicateAction: DuplicateAction = DuplicateAction.UPDATE,
    var boundingBox: SpatialBoundingBox? = null,
    var contextNote: String? = null
) {
    val confidenceLevel: RecognitionConfidenceLevel
        get() = when {
            confidence >= 0.85 -> RecognitionConfidenceLevel.SECURE
            confidence >= 0.60 -> RecognitionConfidenceLevel.PROBABLE
            else -> RecognitionConfidenceLevel.UNCERTAIN
        }
}
