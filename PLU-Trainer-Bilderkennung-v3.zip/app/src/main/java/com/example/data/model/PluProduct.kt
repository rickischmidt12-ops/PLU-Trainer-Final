package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class LearningStatus(val label: String) {
    NEW("Neu"),
    REPEAT("Wiederholen"),
    PRACTICING("Im Training"),
    MASTERED("Gelernt")
}

@Entity(tableName = "plu_products")
data class PluProduct(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val plu: String, // String to preserve leading zeroes or special codes
    val name: String,
    val category: String = "Obst & Gemüse",
    val emoji: String = "🏷️",
    val imageUri: String? = null,
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val lastPracticedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val totalAttempts: Int
        get() = correctCount + wrongCount

    val accuracyPercent: Int
        get() = if (totalAttempts == 0) 0 else ((correctCount.toDouble() / totalAttempts) * 100).toInt()

    val learningStatus: LearningStatus
        get() = when {
            totalAttempts == 0 -> LearningStatus.NEW
            wrongCount > 0 && accuracyPercent < 70 -> LearningStatus.REPEAT
            totalAttempts < 3 || accuracyPercent < 90 -> LearningStatus.PRACTICING
            else -> LearningStatus.MASTERED
        }

    // Weight used by learning algorithm to select question: higher weight = higher priority to practice
    val practiceWeight: Double
        get() = when {
            totalAttempts == 0 -> 4.0 // High priority for unlearned items
            learningStatus == LearningStatus.REPEAT -> 5.0 // Highest priority for frequently missed
            learningStatus == LearningStatus.PRACTICING -> 2.5 // Medium priority
            else -> 1.0 // Lower priority for mastered items
        }
}
