package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.Screen
import com.example.ui.screens.AddPhotosScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PracticeScreen
import com.example.ui.screens.ProductListScreen
import com.example.ui.screens.RecognitionResultScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.PluTrainerTheme
import com.example.ui.viewmodel.PluViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PluTrainerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PluTrainerApp()
                }
            }
        }
    }
}

@Composable
fun PluTrainerApp() {
    val navController = rememberNavController()
    val viewModel: PluViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = Modifier.fillMaxSize()
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToAddPhotos = { navController.navigate(Screen.AddPhotos.route) },
                onNavigateToPractice = { navController.navigate(Screen.Practice.route) },
                onNavigateToProductList = { navController.navigate(Screen.ProductList.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.AddPhotos.route) {
            AddPhotosScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToResults = {
                    navController.navigate(Screen.RecognitionResult.route) {
                        popUpTo(Screen.AddPhotos.route) { inclusive = false }
                    }
                }
            )
        }

        composable(Screen.RecognitionResult.route) {
            RecognitionResultScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onSavedSuccessfully = {
                    navController.navigate(Screen.ProductList.route) {
                        popUpTo(Screen.Home.route) { inclusive = false }
                    }
                }
            )
        }

        composable(Screen.Practice.route) {
            PracticeScreen(
                viewModel = viewModel,
                onNavigateBackToMenu = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Home.route) { inclusive = true }
                    }
                },
                onNavigateToAddPhotos = { navController.navigate(Screen.AddPhotos.route) }
            )
        }

        composable(Screen.ProductList.route) {
            ProductListScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
