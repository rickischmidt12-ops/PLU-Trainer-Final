package com.example

import com.example.data.model.RecognitionConfidenceLevel
import com.example.data.service.SpatialTableLayoutParser
import com.example.data.service.SpatialTextBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PluRecognitionSpatialTest {

    @Test
    fun testScenario1_TenProductsSingleColumn() {
        val rawList = """
            Apfel Gala        1234
            Banane            4321
            Kiwi              2415
            Paprika Rot       3152
            Avocado Hass      4046
            Salatgurke        4062
            Rispentomaten     4087
            Zitrone           4033
            Kaisersemmel      1007
            Buttercroissant   2512
        """.trimIndent()

        val results = SpatialTableLayoutParser.parseText(rawList)
        assertEquals(10, results.size)

        assertEquals("Apfel Gala", results[0].name)
        assertEquals("1234", results[0].plu)

        assertEquals("Banane", results[1].name)
        assertEquals("4321", results[1].plu)

        assertEquals("Kiwi", results[2].name)
        assertEquals("2415", results[2].plu)

        assertEquals("Paprika Rot", results[3].name)
        assertEquals("3152", results[3].plu)

        assertEquals("Avocado Hass", results[4].name)
        assertEquals("4046", results[4].plu)
    }

    @Test
    fun testScenario2_FiftyProductsLongList() {
        val sb = StringBuilder()
        for (i in 1..50) {
            sb.append("Produkt Nummer $i    ${1000 + i}\n")
        }

        val results = SpatialTableLayoutParser.parseText(sb.toString())
        assertEquals(50, results.size)

        assertEquals("Produkt Nummer 1", results[0].name)
        assertEquals("1001", results[0].plu)

        assertEquals("Produkt Nummer 50", results[49].name)
        assertEquals("1050", results[49].plu)
    }

    @Test
    fun testScenario3_TwoColumnsLayout() {
        val multiColumnText = """
            Apfel Gala 1234 | Banane 4321
            Kiwi 2415       | Paprika Rot 3152
            Avocado 4046    | Salatgurke 4062
        """.trimIndent()

        val results = SpatialTableLayoutParser.parseText(multiColumnText)
        assertEquals(6, results.size)

        assertEquals("Apfel Gala", results[0].name)
        assertEquals("1234", results[0].plu)

        assertEquals("Banane", results[1].name)
        assertEquals("4321", results[1].plu)

        assertEquals("Kiwi", results[2].name)
        assertEquals("2415", results[2].plu)

        assertEquals("Paprika Rot", results[3].name)
        assertEquals("3152", results[3].plu)
    }

    @Test
    fun testScenario4_FilterPricesWeightsDatesAndPercentages() {
        val noisyText = """
            Seite 1 / 4   12.04.2025
            Apfel Gala 1kg 1,99 € 1234
            Banane Bio 500g 4321 2.49 EUR -10%
            Kiwi grün 2415 0,89 € / Stk
            Paprika Rot 3152 3.49 €
            KW 16 Angebote
        """.trimIndent()

        val results = SpatialTableLayoutParser.parseText(noisyText)
        assertEquals(4, results.size)

        assertEquals("Apfel Gala", results[0].name)
        assertEquals("1234", results[0].plu)

        assertEquals("Banane Bio", results[1].name)
        assertEquals("4321", results[1].plu)

        assertEquals("Kiwi grün", results[2].name)
        assertEquals("2415", results[2].plu)

        assertEquals("Paprika Rot", results[3].name)
        assertEquals("3152", results[3].plu)
    }

    @Test
    fun testScenario5_LeadingZeroesAndVariablePluLengths() {
        val leadingZeroesText = """
            Bio Bananen 0413
            Kaisersemmel 007
            Bio Avocado 94011
            Zwiebeln 42
        """.trimIndent()

        val results = SpatialTableLayoutParser.parseText(leadingZeroesText)
        assertEquals(4, results.size)

        // Strict leading zeroes preservation
        assertEquals("0413", results[0].plu)
        assertEquals("007", results[1].plu)
        assertEquals("94011", results[2].plu)
        assertEquals("42", results[3].plu)
    }

    @Test
    fun testScenario6_Spatial2DBlocksClustering() {
        // Simulating OCR coordinates (Y coordinates group rows, X coordinates order columns)
        val blocks = listOf(
            // Row 1 (y ~ 100)
            SpatialTextBlock(text = "Apfel Elstar", x = 50.0, y = 102.0),
            SpatialTextBlock(text = "4123", x = 200.0, y = 98.0),
            // Row 2 (y ~ 150)
            SpatialTextBlock(text = "Bio Gurke", x = 48.0, y = 149.0),
            SpatialTextBlock(text = "0418", x = 198.0, y = 151.0)
        )

        val results = SpatialTableLayoutParser.parseSpatialBlocks(blocks, yTolerance = 15.0)
        assertEquals(2, results.size)

        assertEquals("Apfel Elstar", results[0].name)
        assertEquals("4123", results[0].plu)

        assertEquals("Bio Gurke", results[1].name)
        assertEquals("0418", results[1].plu)
        assertTrue(results[1].confidenceLevel == RecognitionConfidenceLevel.SECURE)
    }
}
