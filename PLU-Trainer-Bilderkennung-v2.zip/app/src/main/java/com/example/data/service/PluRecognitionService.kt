package com.example.data.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Log
import com.example.data.model.RecognizedPluItem
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

sealed class RecognitionResult {
    data class Success(val items: List<RecognizedPluItem>) : RecognitionResult()
    data class Error(val userMessage: String, val details: String? = null) : RecognitionResult()
}

/**
 * Local PLU recognition using the bundled ML Kit Latin text recognizer.
 *
 * No image or text is sent to Gemini or another paid AI API. Recognition runs
 * on the device, so there is no shared API quota that users can exhaust.
 */
class PluRecognitionService(private val context: Context) {

    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun analyzeImageUris(uris: List<Uri>): RecognitionResult = withContext(Dispatchers.IO) {
        val bitmaps = uris.mapNotNull { uri ->
            loadAndOrientBitmap(uri).also { bitmap ->
                if (bitmap == null) Log.e("PluRecognition", "Failed to decode bitmap from uri: $uri")
            }
        }

        if (bitmaps.isEmpty()) {
            return@withContext RecognitionResult.Error(
                "Das ausgewählte Bild konnte nicht geladen werden. Bitte versuche es erneut."
            )
        }

        val allItems = mutableListOf<RecognizedPluItem>()
        val errors = mutableListOf<RecognitionResult.Error>()

        for (bitmap in bitmaps) {
            when (val result = analyzeSingleBitmap(bitmap)) {
                is RecognitionResult.Success -> allItems.addAll(result.items)
                is RecognitionResult.Error -> errors.add(result)
            }
        }

        if (allItems.isEmpty()) {
            return@withContext errors.firstOrNull() ?: RecognitionResult.Error(
                "Es wurden keine PLU-Nummern auf den Bildern erkannt. Bitte achte auf ein scharfes, gut ausgeleuchtetes und möglichst frontales Foto der Liste."
            )
        }

        // A PLU may occur only once in a single import batch. Keep the result
        // with the highest confidence if the same PLU was read multiple times.
        val uniqueItems = allItems
            .groupBy { it.plu.trim() }
            .mapNotNull { (_, items) -> items.maxByOrNull { it.confidence } }

        RecognitionResult.Success(uniqueItems)
    }

    suspend fun analyzeSingleBitmap(bitmap: Bitmap): RecognitionResult = withContext(Dispatchers.IO) {
        try {
            // Large enough for small PLU text, but not needlessly huge for OCR.
            val scaledBitmap = scaleBitmapIfNeeded(bitmap, maxDimension = 2560)
            val image = InputImage.fromBitmap(scaledBitmap, 0)
            val visionText = recognizeText(image)

            val items = parseRecognizedText(visionText)
            if (items.isEmpty()) {
                return@withContext RecognitionResult.Error(
                    "Auf dem Foto konnten keine eindeutigen Produkt-/PLU-Zeilen erkannt werden. Bitte fotografiere die Liste scharf, gerade und mit guter Beleuchtung."
                )
            }

            RecognitionResult.Success(items)
        } catch (e: Exception) {
            Log.e("PluRecognition", "Local OCR failed", e)
            RecognitionResult.Error(
                "Fehler bei der lokalen Bilderkennung: ${e.localizedMessage ?: e.message ?: "Unbekannter Fehler"}. Bitte versuche es mit einem anderen Foto erneut."
            )
        }
    }

    private suspend fun recognizeText(image: InputImage): Text = suspendCoroutine { continuation ->
        textRecognizer.process(image)
            .addOnSuccessListener { result -> continuation.resume(result) }
            .addOnFailureListener { error -> continuation.resumeWith(Result.failure(error)) }
    }

    /**
     * Prefer ML Kit's own line grouping because it usually preserves table rows
     * better than rebuilding rows from individual words. If that does not yield
     * enough pairs, fall back to the existing spatial and plain-text parsers.
     */
    private fun parseRecognizedText(visionText: Text): List<RecognizedPluItem> {
        val directLineItems = mutableListOf<RecognizedPluItem>()
        val spatialBlocks = mutableListOf<SpatialTextBlock>()

        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val lineText = line.text.trim()
                if (lineText.isNotBlank()) {
                    SpatialTableLayoutParser.extractItemFromSegment(lineText)?.let { item ->
                        directLineItems.add(item)
                    }
                }

                // Individual elements retain X/Y positions for a fallback when
                // the product name and PLU are emitted as separate OCR pieces.
                for (element in line.elements) {
                    val box = element.boundingBox ?: continue
                    val text = element.text.trim()
                    if (text.isBlank()) continue
                    spatialBlocks.add(
                        SpatialTextBlock(
                            text = text,
                            x = box.left.toDouble(),
                            y = box.centerY().toDouble(),
                            width = box.width().toDouble(),
                            height = box.height().toDouble()
                        )
                    )
                }
            }
        }

        val spatialItems = if (spatialBlocks.isNotEmpty()) {
            val averageHeight = spatialBlocks.map { it.height }.filter { it > 0.0 }.average()
            val tolerance = if (averageHeight.isNaN()) 18.0 else (averageHeight * 0.65).coerceIn(12.0, 45.0)
            SpatialTableLayoutParser.parseSpatialBlocks(spatialBlocks, yTolerance = tolerance)
        } else {
            emptyList()
        }

        val plainTextItems = SpatialTableLayoutParser.parseText(visionText.text)

        // Merge all strategies, then deduplicate by PLU. Direct ML Kit line
        // results get a small confidence advantage because row grouping came
        // directly from the recognizer rather than being reconstructed.
        val merged = buildList {
            addAll(directLineItems.map { it.copy(confidence = (it.confidence + 0.03).coerceAtMost(0.99)) })
            addAll(spatialItems)
            addAll(plainTextItems.map { it.copy(confidence = (it.confidence - 0.05).coerceAtLeast(0.50)) })
        }

        return merged
            .filter { it.name.isNotBlank() && it.plu.matches(Regex("^\\d{2,6}$")) }
            .groupBy { it.plu }
            .mapNotNull { (_, candidates) -> candidates.maxByOrNull { it.confidence } }
    }

    private fun loadAndOrientBitmap(uri: Uri): Bitmap? {
        return try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            val originalBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

            val exif = try {
                ExifInterface(bytes.inputStream())
            } catch (_: Exception) {
                null
            }

            val orientation = exif?.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            ) ?: ExifInterface.ORIENTATION_NORMAL

            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            }

            if (!matrix.isIdentity) {
                Bitmap.createBitmap(
                    originalBitmap,
                    0,
                    0,
                    originalBitmap.width,
                    originalBitmap.height,
                    matrix,
                    true
                )
            } else {
                originalBitmap
            }
        } catch (e: Exception) {
            Log.e("PluRecognition", "Error reading and orienting bitmap for URI: $uri", e)
            null
        }
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap

        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDimension
            newHeight = (maxDimension / ratio).toInt()
        } else {
            newHeight = maxDimension
            newWidth = (maxDimension * ratio).toInt()
        }
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }
}
